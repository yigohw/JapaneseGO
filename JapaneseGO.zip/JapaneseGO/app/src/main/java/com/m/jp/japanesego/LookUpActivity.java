package com.m.jp.japanesego;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.ArrayList;

public class LookUpActivity extends AppCompatActivity {
    Context context;
    ListView lv;
    ArrayList<String> dict;
    int layoutID;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_look_up);
        context = this;

        lv = (ListView) findViewById(R.id.dict_list);
        dict = new ArrayList<String>();
        layoutID = android.R.layout.simple_list_item_1;
        adapter = new ArrayAdapter<String>(this, layoutID, dict);
    }

    public void lookUp(View v){
        EditText et = (EditText) findViewById(R.id.look_up_text);
        try {
            String url = getString(R.string.dict_url1)
                    + et.getText().toString();

            Toast.makeText(context, getString(R.string.looking_up), Toast.LENGTH_SHORT).show();
            LookUpAsync task = new LookUpAsync();
            task.execute(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected class LookUpAsync extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... params) {
            String result = null;
            try {
                String url = params[0];
                Document doc = Jsoup.connect(url).get();

                dict.clear();

                Element cnToCn = doc.getElementById("hhDictTrans");
                if (cnToCn != null)
                    cnToCn = cnToCn.getElementsByClass("sense-title").get(0);
                for (Element e : doc.getElementsByClass("sense-title")){
                    if(e.equals(cnToCn))
                        break;
                    dict.add(e.text());
                }

                if (dict.size() == 0) {
                    Element e  = doc.getElementById("fanyiToggle");
                    if(e != null) {
                        e = e.getElementsByTag("p").get(1);
                        dict.add(getString(R.string.translate) + e.text());
                    }else
                        dict.add(getString(R.string.no_result));
                }

                result = getString(R.string.look_up_success);
            }  catch (Exception e) {
                e.printStackTrace();
                result = getString(R.string.look_up_failure);
            }

            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s.equals(getString(R.string.look_up_failure)))
                Toast.makeText(context, s, Toast.LENGTH_SHORT).show();
            lv.setAdapter(adapter);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            String progress = values[0] + "/" + values[1];
            //Toast.makeText(context, progress, Toast.LENGTH_SHORT).show();
        }
    }
}
