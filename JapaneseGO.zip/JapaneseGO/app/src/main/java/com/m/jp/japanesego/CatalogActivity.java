package com.m.jp.japanesego;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CatalogActivity extends AppCompatActivity {
    Context context;
    String path;
    ListView lv;
    SimpleAdapter adapter;
    List<Map<String, Object>> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);
        context = this;

        list = new ArrayList<Map<String, Object>>();

        path = Environment.getExternalStorageDirectory()
                + "/" + getString(R.string.app_name)
                + "/lesson";
        try {
            getCatalog();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getCatalog() throws Exception {
        File f = new File(path + "/lesson01/info.jpg");
        if (f.exists()) {
            loadCatalog();
        }
        else{
            new File(path).mkdir();

            GetCatalogHtmlAsync task = new GetCatalogHtmlAsync();
            Toast.makeText(context, getString(R.string.loading),Toast.LENGTH_SHORT).show();
            task.execute(getString(R.string.catalog_url), getString(R.string.nhk_home_url));
        }
    }

    protected void loadCatalog() throws IOException {
        File catalog = new File(path);

        for (File lesson : catalog.listFiles()) {
            if (lesson.isHidden())
                continue;
            else if (lesson.isFile())
                continue;

            Document info = Jsoup.parse(new File(lesson.getPath() + "/info.html"), "utf-8");

            Map<String, Object> map = new HashMap<String, Object>();
            map.put("title", info.getElementById("title").text());
            map.put("info", info.getElementById("info").text());
            map.put("href", info.getElementById("href").text());

            Bitmap img = new BitmapFactory().decodeFile(lesson.getPath() + info.getElementById("img").text());
            map.put("img", img);

            list.add(map);
        }
        setAdapter();
    }

    protected class GetCatalogHtmlAsync extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... params) {
            String result = null;
            try {
                String url = params[0];
                String img_home = params[1];
                Document doc = Jsoup.connect(url).get();
                Elements lessons = doc.getElementsByClass("tooltip");

                int index = 0;
                for (Element lesson : lessons) {
                    index++;
                    String title =  lesson.getElementsByClass("lbox").text();
                    String info = lesson.getElementsByClass("desc spNoDisplay").text();
                    String href = url + lesson.select("a").attr("href").substring(2);
                    Bitmap img =  getBitmap(img_home + lesson.select("img").attr("src"));

                    Map<String, Object> map = new HashMap<String, Object>();
                    map.put("title", title);
                    map.put("info", info);
                    map.put("href", href);
                    map.put("img", img);

                    String indexString = "" + index;
                    if(index < 10)
                        indexString = "0" + index;
                    String path_pre = path + "/lesson" + indexString;

                    list.add(map);
                    saveToSDCard(path_pre, map);

                    publishProgress(index, lessons.size());
                }
                result = getString(R.string.load_success);
            }  catch (Exception e) {
                e.printStackTrace();
                result = getString(R.string.load_failure);
            }

            return result;
        }

        protected Bitmap getBitmap(String img_url_str) throws IOException {
            Bitmap bmp = null;
            URL img_url = new URL(img_url_str);
            HttpURLConnection conn = (HttpURLConnection) img_url.openConnection();
            InputStream is = conn.getInputStream();
            bmp = BitmapFactory.decodeStream(is);
            is.close();
            return bmp;
        }

        protected void saveToSDCard(String path_pre, Map map) throws Exception {
            File path = new File(path_pre);
            if(path.exists())
                path.delete();
            path.mkdir();

            Bitmap img = (Bitmap) map.get("img");
            File f = new File(path_pre + "/info.jpg");
            if (f.exists())
                f.delete();
            OutputStream os = new FileOutputStream(f);
            img.compress(Bitmap.CompressFormat.JPEG, 30, os);
            os.flush();
            os.close();

            OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(path_pre + "/info.html"), "utf-8");
            out.write("<p id='title'>" + map.get("title").toString() + "</p>\n");
            out.write("<p id='info'>" + map.get("info").toString() + "</p>\n");
            out.write("<p id='href'>" + map.get("href").toString() + "</p>\n");
            out.write("<p id='img'>/info.jpg</p>\n");
            out.flush();
            out.close();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(context, s, Toast.LENGTH_SHORT).show();
            setAdapter();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            String progress = values[0] + "/" + values[1];
            //Toast.makeText(context, progress, Toast.LENGTH_SHORT).show();
        }
    }

    protected void setAdapter(){
        lv = (ListView) findViewById(R.id.catalog_list);
        adapter = new SimpleAdapter(context, list,
                R.layout.catalog_lesson, new String[]{"img", "title", "href", "info"},
                new int[] {R.id.catalog_lesson_img, R.id.catalog_lesson_title,
                        R.id.catalog_lesson_href, R.id.catalog_lesson_info});
        adapter.setViewBinder(new ImgViewBinder());
        lv.setAdapter(adapter);

        AdapterView.OnItemClickListener onItemClickListener = new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos,long id) {
                goIntoLesson(pos + 1);
            }
        };
        lv.setOnItemClickListener(onItemClickListener);
    }

    protected class ImgViewBinder implements SimpleAdapter.ViewBinder{
        @Override
        public boolean setViewValue(View view, Object data, String textRepresentation) {
            if((view instanceof ImageView)&(data instanceof Bitmap))
            {
                ImageView iv = (ImageView)view;
                Bitmap bmp = (Bitmap)data;
                iv.setImageBitmap(bmp);
                return true;
            }
            return false;
        }
    }

    protected void goIntoLesson(int number){
        String index = "" + number;
        if (number < 10)
            index = "0" + number;
        String lesson_path = path + "/lesson" + index + "/content.html";
        File f = new File(lesson_path);
        if (!f.exists() && !hasNetWork()){
            Toast.makeText(context, getString(R.string.no_network)
                    + "+" + getString(R.string.not_download), Toast.LENGTH_LONG).show();
        }else {
            Intent intent = new Intent();
            intent.setClass(CatalogActivity.this, LessonActivity.class);
            Bundle bun = new Bundle();
            bun.putInt("number", number);
            intent.putExtras(bun);
            startActivity(intent);
        }
    }

    public boolean hasNetWork() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo[] infos = cm.getAllNetworkInfo();
            if (infos != null) {
                for (NetworkInfo ni : infos) {
                    if (ni.isConnected()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

}
