package com.m.jp.japanesego;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;

public class HomeActivity extends AppCompatActivity {
    String path;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        context = this;

        mkHomeDir();
    }

    public void mkHomeDir(){
        path = Environment.getExternalStorageDirectory() +
                "/" + getString(R.string.app_name);
        File dir = new File(path);
        if(!dir.exists()) {
            dir.mkdir();
        }
    }

    public void goIntoCatalog(View v){
        String lesson_path = path + "/lesson/lesson01/info.jpg";
        File f = new File(lesson_path);
        if (!f.exists() && !hasNetWork()){
                Toast.makeText(context, getString(R.string.no_network)
                        + "+" + getString(R.string.not_download), Toast.LENGTH_LONG).show();
        }
        else{
            Intent intent = new Intent();
            intent.setClass(HomeActivity.this, CatalogActivity.class);
            startActivity(intent);
        }
    }

    public void goIntoKana(View v){
        String lesson_path = path + "/kana/kana.html";
        File f = new File(lesson_path);
        if (!f.exists() && !hasNetWork()){
            Toast.makeText(context, getString(R.string.no_network)
                    + "+" + getString(R.string.not_download), Toast.LENGTH_LONG).show();
        }
        else{
            Intent intent = new Intent();
            intent.setClass(HomeActivity.this, KanaActivity.class);
            startActivity(intent);
        }
    }

    public void goToLookUp(View v){
        if (!hasNetWork()){
            Toast.makeText(context, getString(R.string.no_network), Toast.LENGTH_LONG).show();
        }
        else{
            Intent intent = new Intent();
            intent.setClass(HomeActivity.this, LookUpActivity.class);
            startActivity(intent);
        }
    }
    public boolean hasNetWork() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo[] infos = cm.getAllNetworkInfo();
            if (infos != null) {
                for (NetworkInfo ni : infos) {
                    if (ni.isConnected()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

}
