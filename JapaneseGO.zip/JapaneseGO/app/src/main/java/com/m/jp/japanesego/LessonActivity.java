package com.m.jp.japanesego;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LessonActivity extends AppCompatActivity {
    int number;
    String path;
    Map<String, Object> info_map;
    List<Map<String, Object>> list;
    ListView lv;
    SimpleAdapter adapter;
    String teacher;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson);
        context = this;

        list = new ArrayList<Map<String, Object>>();

        Bundle bun = this.getIntent().getExtras();
        number = bun.getInt("number");
        String index = "" + number;
        if (number < 10)
            index = "0" + number;
        path = Environment.getExternalStorageDirectory()
                + "/" + getString(R.string.app_name)
                + "/lesson"
                + "/lesson" + index;
        getLesson();
    }

    protected void getLesson() {
        getInfo();
        getContent();
    }

    protected void getInfo() {
        Document info = null;
        try {
            info = Jsoup.parse(new File(path + "/info.html"), "utf-8");
        } catch (IOException e) {
            e.printStackTrace();
        }

        info_map = new HashMap<String, Object>();
        info_map.put("title", info.getElementById("title").text());
        info_map.put("info", info.getElementById("info").text());
        info_map.put("href", info.getElementById("href").text());

        Bitmap img = new BitmapFactory().decodeFile(path + "/info.jpg");

        info_map.put("img", img);

        setInfo();
    }

    protected void setInfo(){
        TextView title = (TextView) findViewById(R.id.lesson_title);
        title.setText((String) info_map.get("title"));
        TextView info = (TextView) findViewById(R.id.lesson_info);
        info.setText((String) info_map.get("info"));
        ImageView img = (ImageView) findViewById(R.id.lesson_img);
        img.setImageBitmap((Bitmap) info_map.get("img"));
    }

    protected void getContent() {
        String full_path = path + "/content.html";
        File f = new File(full_path);
        if (f.exists()) {
            setContent();
        } else {
                    GetLessonHtmlAsync task = new GetLessonHtmlAsync();
                    Toast.makeText(context, getString(R.string.loading), Toast.LENGTH_SHORT).show();
                    task.execute((String) info_map.get("href"));
            }
        }

    protected void setContent(){
        Document content = null;
        try {
            content = Jsoup.parse(new File(path + "/content.html"), "utf-8");
        } catch (IOException e) {
            e.printStackTrace();
        }

        Elements ja_names = content.getElementsByClass("ja-name");
        Elements cn_names = content.getElementsByClass("cn-name");
        Elements ja_sentences = content.getElementsByClass("ja-sentence");
        Elements ro_sentences = content.getElementsByClass("ro-sentence");
        Elements cn_sentences = content.getElementsByClass("cn-sentence");
        Elements audio_srcs = content.getElementsByClass("audio-src");

        for (int i = 0; i < audio_srcs.size(); i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("ja-name", ja_names.get(i).text());
            map.put("ja-sentence", ja_sentences.get(i).text());
            map.put("cn-name", cn_names.get(i).text());
            map.put("ro-sentence", ro_sentences.get(i).text());
            map.put("cn-sentence", cn_sentences.get(i).text());
            map.put("audio-src", audio_srcs.get(i).text());

            list.add(map);
        }

        setAdapter();

        teacher = content.getElementsByClass("teacher").text();
        setTeacher();
    }

    protected void setTeacher(){
        TextView text = (TextView) findViewById(R.id.teacher);
        text.setText(teacher);
        text.setMovementMethod(new ScrollingMovementMethod());
    }

    protected class GetLessonHtmlAsync extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... params) {
            String result = null;
            try {
                String url = params[0];
                Document doc = Jsoup.connect(url).get();

                Elements ja = doc.getElementsByClass("line-ja");
                Elements ro = doc.getElementsByClass("line-yomi");
                Elements cn = doc.getElementsByClass("sp-view spDisplay");

                int i = 0;
                for (Element e : ja) {
                    Map<String, Object> map = new HashMap<String, Object>();
                    String ja_name = e.select("th").text();
                    String ja_sentence = e.select("td").first().text();

                    Element er = ro.get(i);
                    String cn_name = er.select("th").text();
                    String ro_sentence = er.select("td").first().text();

                    Element ec = cn.get(i);
                    String cn_sentence = ec.text();

                    ro_sentence = ro_sentence.replace(cn_sentence, "").trim();

                    String audio_src = getString(R.string.audio_url_1) + number
                            + getString(R.string.audio_url_2) + (i + 1)
                            + getString(R.string.audio_url_3);
                    map.put("audio-src", audio_src);

                    map.put("ja-name", ja_name);
                    map.put("ja-sentence", ja_sentence);
                    map.put("cn-name", cn_name);
                    map.put("ro-sentence", ro_sentence);
                    map.put("cn-sentence", cn_sentence);

                    list.add(map);
                    i++;
                    publishProgress(i, ja.size());
                }

                Element teach = doc.getElementById("a-teacher");
                String teach_url = getString(R.string.nhk_home_url) + teach.select("a").attr("href");
                teacher = Jsoup.connect(teach_url).get().getElementById("teacher-box").text();
                saveToSDCard(list);

                result = getString(R.string.load_success);
            } catch (Exception e) {
                e.printStackTrace();
                result = getString(R.string.load_failure);
            }

            return result;
        }

        protected void saveToSDCard(List<Map<String, Object>> list) throws Exception {
            OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(path + "/content.html"), "utf-8");
            int i = 1;
            for(Map map : list) {
                URL audio_src = new URL((String)map.get("audio-src"));
                HttpURLConnection conn = (HttpURLConnection) audio_src.openConnection();
                InputStream is = conn.getInputStream();

                FileOutputStream fos = new FileOutputStream(path + "/" + i + ".mp3");

                byte[] b = new byte[1024];
                while(is.read(b) != -1)
                    fos.write(b);
                is.close();
                fos.close();

                map.put("audio-src", "/" + i + ".mp3");
                list.set(i-1, map);

                out.write("<p class='audio-src'>" + map.get("audio-src").toString() + "</p>\n");
                out.write("<p class='ja-name'>" + map.get("ja-name").toString() + "</p>\n");
                out.write("<p class='cn-name'>" + map.get("cn-name").toString() + "</p>\n");
                out.write("<p class='ja-sentence'>" + map.get("ja-sentence").toString() + "</p>\n");
                out.write("<p class='ro-sentence'>" + map.get("ro-sentence").toString() + "</p>\n");
                out.write("<p class='cn-sentence'>" + map.get("cn-sentence").toString() + "</p>\n");
                out.write("<br/>");

                out.flush();
                i++;
            }

            out.write("<p class='teacher'>" + teacher + "</p>\n");
            out.flush();
            out.close();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(context, s, Toast.LENGTH_SHORT).show();
            setAdapter();
            setTeacher();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            String progress = values[0] + "/" + values[1];
            //Toast.makeText(context, progress, Toast.LENGTH_SHORT).show();
        }
    }

    protected void setAdapter(){
        lv = (ListView) findViewById(R.id.lesson_content_list);
        adapter = new SimpleAdapter(context, list, R.layout.lesson_content,
                new String[]{"ja-name", "cn-name", "audio-src", "ja-sentence", "ro-sentence", "cn-sentence"},
                new int[] {R.id.lesson_ja_name, R.id.lesson_cn_name, R.id.lesson_audio,
                        R.id.lesson_ja_sentence, R.id.lesson_ro_sentence,R.id.lesson_cn_sentence});
        lv.setAdapter(adapter);

        AdapterView.OnItemClickListener onItemClickListener = new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                Map<String, Object> map = list.get(pos);
                String src = (String) map.get("audio-src");
                src = path + src;

                MediaPlayer mp = new MediaPlayer();
                try {
                    mp.setDataSource(src);
                    mp.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                //Toast.makeText(context, src, Toast.LENGTH_LONG).show();
                mp.start();
            }
        };
        lv.setOnItemClickListener(onItemClickListener);
    }
}
